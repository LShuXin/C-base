#include<stdio.h>
#include<stdlib.h> 
typedef struct
{
    char name[31];
    int age;
    float score;
}Student;


//��ӡStudent������Ϣ
void show(const Student * ps)
{
    printf("name:%s , age:%d , score:%.2f\n",ps->name,ps->age,ps->score);   
}





