#include<stdio.h>
#include<stdlib.h> 
void swap_bad(int a,int b);
void swap_ok(int*pa,int*pb);

int main()
{
    int a = 5;
    int b = 3;
    swap_bad(a,b);       //Can`t swap;
    swap_ok(&a,&b);      //OK
    return 0;
}

//�����д��
void swap_bad(int a,int b)
{
    int t;
    t=a;
    a=b;
    b=t;
}

//��ȷ��д����ͨ��ָ��
void swap_ok(int*pa,int*pb)
{
    int t;
    t=*pa;
    *pa=*pb;
    *pb=t;
}




